package com.example.sadiahossain_project2

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener

class MainActivity : AppCompatActivity() {

    private lateinit var amountInput: EditText
    private lateinit var tipSeekBar: SeekBar
    private lateinit var percentageTextView: TextView
    private lateinit var tipDescription: TextView
    private lateinit var tipAmount: TextView
    private lateinit var grandTotal: TextView
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("TipCalculatorPrefs", MODE_PRIVATE)

        amountInput = findViewById(R.id.amountInput)
        tipSeekBar = findViewById(R.id.tipSeekBar)
        percentageTextView = findViewById(R.id.percentageTextView)
        tipDescription = findViewById(R.id.tipDescription)
        tipAmount = findViewById(R.id.tipAmount)
        grandTotal = findViewById(R.id.grandTotal)

        tipSeekBar.progress = sharedPreferences.getInt("TIP_PERCENTAGE", 20)
        updateUI()

        tipSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                saveTipPercentage(progress)
                updateUI()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        amountInput.addTextChangedListener {
            updateUI()
        }
    }

    private fun saveTipPercentage(value: Int) {
        sharedPreferences.edit().putInt("TIP_PERCENTAGE", value).apply()
    }

    private fun updateUI() {
        val tipPercentage = tipSeekBar.progress
        val amount = amountInput.text.toString().toDoubleOrNull() ?: 0.0

        percentageTextView.text = "$tipPercentage%"

        val tip = (amount * tipPercentage) / 100
        val total = amount + tip

        tipAmount.text = String.format("Tip: $%.2f", tip)
        grandTotal.text = String.format("Total: $%.2f", total)

        when (tipPercentage) {
            in 0..9 -> updateTipDescription("Poor", R.color.red)
            in 10..15 -> updateTipDescription("OK", R.color.orange)
            in 16..20 -> updateTipDescription("Good", R.color.green)
            in 21..25 -> updateTipDescription("Great", R.color.dark_green)
            in 26..35 -> updateTipDescription("Awesome", R.color.blue)
        }
    }

    private fun updateTipDescription(description: String, colorId: Int) {
        tipDescription.text = description
        tipDescription.setTextColor(ContextCompat.getColor(this, colorId))
    }
}
